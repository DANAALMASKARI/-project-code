package com.my.newproject;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ViewProductActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private FloatingActionButton _fab;
	private String fontName = "";
	private String typeace = "";
	private String WA = "";
	private String call = "";
	private double pos = 0;
	private String key = "";
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	
	private LinearLayout lineartoolbar;
	private LinearLayout linear_bg;
	private ImageView imageview3;
	private TextView textview1;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout img_slide;
	private LinearLayout linear7;
	private TextView nameproduct;
	private TextView ownername;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private TextView textview3;
	private TextView description;
	private ViewPager viewpager1;
	private LinearLayout linear1;
	private LinearLayout point1;
	private LinearLayout point2;
	private LinearLayout point3;
	private LinearLayout point4;
	private LinearLayout point5;
	private TextView location;
	private ImageView imageview6;
	private TextView price;
	private TextView textview7;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview5;
	private ImageView imageview4;
	
	private DatabaseReference DB_items = _firebase.getReference("DB_items");
	private ChildEventListener _DB_items_child_listener;
	private Intent wa_c = new Intent();
	private TimerTask t;
	private FirebaseAuth authUser;
	private OnCompleteListener<AuthResult> _authUser_create_user_listener;
	private OnCompleteListener<AuthResult> _authUser_sign_in_listener;
	private OnCompleteListener<Void> _authUser_reset_password_listener;
	private OnCompleteListener<Void> authUser_updateEmailListener;
	private OnCompleteListener<Void> authUser_updatePasswordListener;
	private OnCompleteListener<Void> authUser_emailVerificationSentListener;
	private OnCompleteListener<Void> authUser_deleteUserListener;
	private OnCompleteListener<Void> authUser_updateProfileListener;
	private OnCompleteListener<AuthResult> authUser_phoneAuthListener;
	private OnCompleteListener<AuthResult> authUser_googleSignInListener;
	
	private DatabaseReference DB_items2 = _firebase.getReference("DB_items2");
	private ChildEventListener _DB_items2_child_listener;
	private DatabaseReference DB_items1 = _firebase.getReference("DB_items1");
	private ChildEventListener _DB_items1_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_product);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		
		lineartoolbar = findViewById(R.id.lineartoolbar);
		linear_bg = findViewById(R.id.linear_bg);
		imageview3 = findViewById(R.id.imageview3);
		textview1 = findViewById(R.id.textview1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear2 = findViewById(R.id.linear2);
		img_slide = findViewById(R.id.img_slide);
		linear7 = findViewById(R.id.linear7);
		nameproduct = findViewById(R.id.nameproduct);
		ownername = findViewById(R.id.ownername);
		linear3 = findViewById(R.id.linear3);
		linear6 = findViewById(R.id.linear6);
		textview3 = findViewById(R.id.textview3);
		description = findViewById(R.id.description);
		viewpager1 = findViewById(R.id.viewpager1);
		linear1 = findViewById(R.id.linear1);
		point1 = findViewById(R.id.point1);
		point2 = findViewById(R.id.point2);
		point3 = findViewById(R.id.point3);
		point4 = findViewById(R.id.point4);
		point5 = findViewById(R.id.point5);
		location = findViewById(R.id.location);
		imageview6 = findViewById(R.id.imageview6);
		price = findViewById(R.id.price);
		textview7 = findViewById(R.id.textview7);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview5 = findViewById(R.id.imageview5);
		imageview4 = findViewById(R.id.imageview4);
		authUser = FirebaseAuth.getInstance();
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		viewpager1.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {
				
			}
			
			@Override
			public void onPageSelected(int _position) {
				_pointt(_position);
			}
			
			@Override
			public void onPageScrollStateChanged(int _scrollState) {
				
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DB_items.child(getIntent().getStringExtra("uid")).removeValue();
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								finish();
							}
						});
					}
				};
				_timer.schedule(t, (int)(800));
			}
		});
		
		_DB_items_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					key = "";
					if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						_fab.show();
					}
					else {
						_fab.hide();
					}
					if (_childValue.containsKey("main_img")) {
						{
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("img", _childValue.get("main_img").toString());
							listMap.add(_item);
						}
						
						point1.setVisibility(View.VISIBLE);
					}
					if (_childValue.containsKey("Img1")) {
						{
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("img", _childValue.get("Img1").toString());
							listMap.add(_item);
						}
						
						point2.setVisibility(View.VISIBLE);
					}
					if (_childValue.containsKey("Img2")) {
						point3.setVisibility(View.VISIBLE);
						if (_childValue.get("Img2").toString().equals("")) {
							point3.setVisibility(View.GONE);
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("Img2").toString());
								listMap.add(_item);
							}
							
						}
					}
					if (_childValue.containsKey("Img3")) {
						point4.setVisibility(View.VISIBLE);
						if (_childValue.get("Img3").toString().equals("")) {
							point4.setVisibility(View.GONE);
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("Img3").toString());
								listMap.add(_item);
							}
							
						}
					}
					if (_childValue.containsKey("Img4")) {
						point5.setVisibility(View.VISIBLE);
						if (_childValue.get("Img4").toString().equals("")) {
							point5.setVisibility(View.GONE);
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("Img4").toString());
								listMap.add(_item);
							}
							
						}
					}
					if (_childValue.containsKey("OwnerProduct")) {
						ownername.setText(_childValue.get("OwnerProduct").toString());
					}
					if (_childValue.containsKey("call")) {
						call = _childValue.get("call").toString();
						linear4.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								wa_c.setAction(Intent.ACTION_CALL);
								wa_c.setData(Uri.parse("tel:".concat(_childValue.get("call").toString())));
								startActivity(wa_c);
							}
						});
					}
					if (_childValue.containsKey("WA")) {
						linear5.setVisibility(View.VISIBLE);
						WA = _childValue.get("WA").toString();
						if (_childValue.get("WA").toString().equals("")) {
							linear5.setVisibility(View.GONE);
						}
						linear5.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								wa_c.setAction(Intent.ACTION_VIEW);
								wa_c.setData(Uri.parse("https://wa.me/".concat(_childValue.get("WA").toString())));
								startActivity(wa_c);
							}
						});
					}
					if (_childValue.containsKey("price")) {
						price.setText(_childValue.get("price").toString());
					}
					if (_childValue.containsKey("description")) {
						description.setText(_childValue.get("description").toString());
					}
					if (_childValue.containsKey("name")) {
						nameproduct.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("Location")) {
						location.setText(_childValue.get("Location").toString());
					}
				}
				_refresh();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		DB_items.addChildEventListener(_DB_items_child_listener);
		
		_DB_items2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("item").equals("Hotel")) {
					
				}
				else {
					if (_childKey.equals(getIntent().getStringExtra("uid"))) {
						key = "";
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							_fab.show();
						}
						else {
							_fab.hide();
						}
						if (_childValue.containsKey("main_img")) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("main_img").toString());
								listMap.add(_item);
							}
							
							point1.setVisibility(View.VISIBLE);
						}
						if (_childValue.containsKey("Img1")) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("Img1").toString());
								listMap.add(_item);
							}
							
							point2.setVisibility(View.VISIBLE);
						}
						if (_childValue.containsKey("Img2")) {
							point3.setVisibility(View.VISIBLE);
							if (_childValue.get("Img2").toString().equals("")) {
								point3.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img2").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("Img3")) {
							point4.setVisibility(View.VISIBLE);
							if (_childValue.get("Img3").toString().equals("")) {
								point4.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img3").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("Img4")) {
							point5.setVisibility(View.VISIBLE);
							if (_childValue.get("Img4").toString().equals("")) {
								point5.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img4").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("OwnerProduct")) {
							ownername.setText(_childValue.get("OwnerProduct").toString());
						}
						if (_childValue.containsKey("call")) {
							call = _childValue.get("call").toString();
						}
						if (_childValue.containsKey("WA")) {
							linear5.setVisibility(View.VISIBLE);
							WA = _childValue.get("WA").toString();
							if (_childValue.get("WA").toString().equals("")) {
								linear5.setVisibility(View.GONE);
							}
						}
						if (_childValue.containsKey("price")) {
							price.setText(_childValue.get("price").toString());
						}
						if (_childValue.containsKey("description")) {
							description.setText(_childValue.get("description").toString());
						}
						if (_childValue.containsKey("name")) {
							nameproduct.setText(_childValue.get("name").toString());
						}
						location.setText(_childValue.get("Location_from").toString().concat("To".concat(_childValue.get("Location_to").toString())));
					}
					_refresh();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		DB_items2.addChildEventListener(_DB_items2_child_listener);
		
		_DB_items1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("item").equals("Hotel")) {
					if (_childKey.equals(getIntent().getStringExtra("uid"))) {
						key = "";
						if (_childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							_fab.show();
						}
						else {
							_fab.hide();
						}
						if (_childValue.containsKey("main_img")) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("main_img").toString());
								listMap.add(_item);
							}
							
							point1.setVisibility(View.VISIBLE);
						}
						if (_childValue.containsKey("Img1")) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("img", _childValue.get("Img1").toString());
								listMap.add(_item);
							}
							
							point2.setVisibility(View.VISIBLE);
						}
						if (_childValue.containsKey("Img2")) {
							point3.setVisibility(View.VISIBLE);
							if (_childValue.get("Img2").toString().equals("")) {
								point3.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img2").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("Img3")) {
							point4.setVisibility(View.VISIBLE);
							if (_childValue.get("Img3").toString().equals("")) {
								point4.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img3").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("Img4")) {
							point5.setVisibility(View.VISIBLE);
							if (_childValue.get("Img4").toString().equals("")) {
								point5.setVisibility(View.GONE);
							}
							else {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("img", _childValue.get("Img4").toString());
									listMap.add(_item);
								}
								
							}
						}
						if (_childValue.containsKey("OwnerProduct")) {
							ownername.setText(_childValue.get("OwnerProduct").toString());
						}
						if (_childValue.containsKey("call")) {
							call = _childValue.get("call").toString();
						}
						if (_childValue.containsKey("WA")) {
							linear5.setVisibility(View.VISIBLE);
							WA = _childValue.get("WA").toString();
							if (_childValue.get("WA").toString().equals("")) {
								linear5.setVisibility(View.GONE);
							}
						}
						if (_childValue.containsKey("price")) {
							price.setText(_childValue.get("price").toString());
						}
						if (_childValue.containsKey("description")) {
							description.setText(_childValue.get("description").toString());
						}
						if (_childValue.containsKey("name")) {
							nameproduct.setText(_childValue.get("name").toString());
						}
						if (_childValue.containsKey("Location")) {
							location.setText(_childValue.get("Location").toString());
						}
					}
					_refresh();
				}
				else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		DB_items1.addChildEventListener(_DB_items1_child_listener);
		
		authUser_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		authUser_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_authUser_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_authUser_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_authUser_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF3F51B5));
		linear4.setElevation((float)8);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF3F51B5));
		linear5.setElevation((float)8);
		_changeActivityFont("tajawal_bold");
		_pointt(0);
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(key)) {
			_fab.show();
		}
		else {
			_fab.hide();
		}
	}
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _refresh() {
		viewpager1.setAdapter(new Viewpager1Adapter(listMap));
		((PagerAdapter)viewpager1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _pointt(final double _pos) {
		if (0 == _pos) {
			point1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF9FA8DA));
			point5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
		}
		if (1 == _pos) {
			point2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF9FA8DA));
			point1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
		}
		if (2 == _pos) {
			point3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF9FA8DA));
			point2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
		}
		if (3 == _pos) {
			point4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF9FA8DA));
			point3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
		}
		if (4 == _pos) {
			point5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF9FA8DA));
			point4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
			point1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3F51B5));
		}
	}
	
	public class Viewpager1Adapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public Viewpager1Adapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public Viewpager1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.cus, _container, false);
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img").toString())).into(imageview1);
			
			_container.addView(_view);
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}