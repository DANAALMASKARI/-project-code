package com.my.newproject;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> m = new HashMap<>();
	private String name = "";
	private String package_name = "";
	
	private LinearLayout l;
	private ScrollView vscroll1;
	private RelativeLayout linear_bg;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView imageview8;
	private TextView textview7;
	private LinearLayout linear3;
	private LinearLayout item1;
	private LinearLayout item2;
	private TextView textview1;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView imageview2;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private ImageView _drawer_imageview1;
	private LinearLayout _drawer_LinearHomee;
	private LinearLayout _drawer_lin;
	private LinearLayout _drawer_linearUpdatee;
	private LinearLayout _drawer_lin2;
	private LinearLayout _drawer_linearRatt;
	private LinearLayout _drawer_lin3;
	private LinearLayout _drawer_linearAppInfoo;
	private LinearLayout _drawer_linear11;
	private LinearLayout _drawer_linear13;
	private LinearLayout _drawer_linearMoreAppp;
	private LinearLayout _drawer_linear15;
	private LinearLayout _drawer_linear16;
	private LinearLayout _drawer_linearExitt;
	private ImageView _drawer_imageview15;
	private TextView _drawer_textview1;
	private ImageView _drawer_imageview2;
	private ImageView _drawer_imageview14;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview3;
	private ImageView _drawer_imageview13;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview4;
	private ImageView _drawer_imageview12;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview5;
	private ImageView _drawer_imageview10;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview7;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview8;
	
	private Intent inT = new Intent();
	private FirebaseAuth authUser;
	private OnCompleteListener<AuthResult> _authUser_create_user_listener;
	private OnCompleteListener<AuthResult> _authUser_sign_in_listener;
	private OnCompleteListener<Void> _authUser_reset_password_listener;
	private OnCompleteListener<Void> authUser_updateEmailListener;
	private OnCompleteListener<Void> authUser_updatePasswordListener;
	private OnCompleteListener<Void> authUser_emailVerificationSentListener;
	private OnCompleteListener<Void> authUser_deleteUserListener;
	private OnCompleteListener<Void> authUser_updateProfileListener;
	private OnCompleteListener<AuthResult> authUser_phoneAuthListener;
	private OnCompleteListener<AuthResult> authUser_googleSignInListener;
	
	private DatabaseReference DBUser = _firebase.getReference("DBUser");
	private ChildEventListener _DBUser_child_listener;
	private Intent in_url = new Intent();
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		l = findViewById(R.id.l);
		vscroll1 = findViewById(R.id.vscroll1);
		linear_bg = findViewById(R.id.linear_bg);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		imageview8 = findViewById(R.id.imageview8);
		textview7 = findViewById(R.id.textview7);
		linear3 = findViewById(R.id.linear3);
		item1 = findViewById(R.id.item1);
		item2 = findViewById(R.id.item2);
		textview1 = findViewById(R.id.textview1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		imageview2 = findViewById(R.id.imageview2);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_LinearHomee = _nav_view.findViewById(R.id.LinearHomee);
		_drawer_lin = _nav_view.findViewById(R.id.lin);
		_drawer_linearUpdatee = _nav_view.findViewById(R.id.linearUpdatee);
		_drawer_lin2 = _nav_view.findViewById(R.id.lin2);
		_drawer_linearRatt = _nav_view.findViewById(R.id.linearRatt);
		_drawer_lin3 = _nav_view.findViewById(R.id.lin3);
		_drawer_linearAppInfoo = _nav_view.findViewById(R.id.linearAppInfoo);
		_drawer_linear11 = _nav_view.findViewById(R.id.linear11);
		_drawer_linear13 = _nav_view.findViewById(R.id.linear13);
		_drawer_linearMoreAppp = _nav_view.findViewById(R.id.linearMoreAppp);
		_drawer_linear15 = _nav_view.findViewById(R.id.linear15);
		_drawer_linear16 = _nav_view.findViewById(R.id.linear16);
		_drawer_linearExitt = _nav_view.findViewById(R.id.linearExitt);
		_drawer_imageview15 = _nav_view.findViewById(R.id.imageview15);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_imageview14 = _nav_view.findViewById(R.id.imageview14);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_imageview13 = _nav_view.findViewById(R.id.imageview13);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_imageview12 = _nav_view.findViewById(R.id.imageview12);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		authUser = FirebaseAuth.getInstance();
		
		imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		item1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				inT.putExtra("item", "Hotel");
				inT.setClass(getApplicationContext(), ItemActivity.class);
				startActivity(inT);
			}
		});
		
		item2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				inT.putExtra("item", "Flights");
				inT.setClass(getApplicationContext(), ItemActivity.class);
				startActivity(inT);
			}
		});
		
		_DBUser_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("name")) {
						name = _childValue.get("name").toString();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		DBUser.addChildEventListener(_DBUser_child_listener);
		
		_drawer_LinearHomee.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
			}
		});
		
		_drawer_linearUpdatee.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in_url.setAction(Intent.ACTION_VIEW);
				in_url.setData(Uri.parse("https://play.google.com/store/apps/details?id=".concat(package_name)));
				startActivity(in_url);
			}
		});
		
		_drawer_linearRatt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer_linearMoreAppp.performClick();
			}
		});
		
		_drawer_linearAppInfoo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_drawer_linearMoreAppp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().signOut();
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								inT.setClass(getApplicationContext(), LoginActivity.class);
								startActivity(inT);
								finish();
							}
						});
					}
				};
				_timer.schedule(t, (int)(800));
			}
		});
		
		_drawer_linearExitt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finishAffinity();
			}
		});
		
		authUser_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		authUser_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		authUser_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_authUser_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_authUser_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_authUser_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		package_name = (getApplicationContext().getPackageName());
		linear1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[] {0xFF5C6BC0,0xFF1A237E}));
		item1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		item1.setElevation((float)10);
		item2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		item2.setElevation((float)10);
		_changeActivityFont("tajawal_bold");
		_hide();
		setTitle("");
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		} else {
			super.onBackPressed();
		}
	}
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _hide() {
		//by Sketchware King.
		try{ 
			getSupportActionBar().hide(); 
		} catch (Exception e){}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}